//2020105614 ��ǻ�Ͱ��а� ���ؼ�
#include <stdio.h>

int main() {
	char names[10][20] = { "kim", "lee", "sin", "jo", "kim2", "chae", "jin", "bak", "so", "choi" };

	printf("�迭 �ʱ�ȭ\n");
	for (int elumsu = 0; elumsu < 10; elumsu++) {
		printf("%6s", names[elumsu]);
	}
	printf("\n");
	
	char temp[20];


	for (int elumsu = 0; elumsu < 10; elumsu++) {
		for (int elumsu2 = 0; elumsu2 < 10 - elumsu; elumsu2++) {
			if (strcmp(names[elumsu2], names[elumsu2 + 1]) > 0) {
				strcpy_s(temp, 20, names[elumsu]);
				strcpy_s(names[elumsu2], 20, names[elumsu]);
				strcpy_s(names[elumsu2 + 1], 20, temp);
			}
		}
	}

	printf("Sorted Result\n");
	for (int elumsu = 0; elumsu < 10; elumsu++) {
		printf("%6s", names[elumsu]);
	}

	return 0;
}