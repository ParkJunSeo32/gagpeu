//2020105614 ��ǻ�Ͱ��а� ���ؼ�
#include <stdio.h>

struct corop {
	char boooseo[10];
	char name[20];
	char which[20];
	int wallet;
};


void print(struct corop c) {
	puts(c.boooseo);
	puts(c.name);
	puts(c.which);
	printf("%10d", c.wallet * 12);
}

int main() {
	int num = 1;
	while (1) {
		struct corop c;

		printf("�μ� ?(����:end) ");
		gets_s(c.boooseo, 10);
		if (strcmp(c.boooseo, "end") == 0)
			break;
		printf(",   ");

		printf("���� ? ");
		gets_s(c.name, 20);
		printf(",    ");

		printf("���� => ");
		gets_s(c.which, 20);
		printf(",");

		printf("���� ? ");
		scanf_s(" %d\n", c.wallet);
		
		num++;
	}

	for (int i = 0; i < num; i++) {
		print(c);
	}

	return 0;
}