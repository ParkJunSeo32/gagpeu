//2020105614 ��ǻ�Ͱ��а� ���ؼ�
#include <stdio.h>

void fibo_func(int num);
int get_fibo(int num);

int main() {
	printf("����� �Ǻ���ġ �� �Է� ?(0���� ū��) ");
	int fibosu;
	scanf_s(" %d", &fibosu);

	fibo_func(fibosu);

	return 0;
}

void fibo_func(int num) {
	if (num == 0)
		printf("    %d.", 0);
	else if (num == 1)
		printf("    %d.", 1);
	else {
		printf("    %d", get_fibo(num));
		fibo_func(num - 1);
	}

}

int get_fibo(int num) {

	if (num == 0)
		return 0;

	else if (num == 1)
		return 1;

	else return
		get_fibo(num - 1) + get_fibo(num - 2);

}